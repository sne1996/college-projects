package com.example.trackandtrace.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.trackandtrace.R;
import com.example.trackandtrace.utils.DBUtil;

public class RegisterActivity extends AppCompatActivity {


    EditText uname,pass,name,mail,addr,mob;
    Button reg,logi,clr;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        uname=findViewById(R.id.edt_uname);
        pass=findViewById(R.id.edt_pass);
        name=findViewById(R.id.edt_name);
        mail=findViewById(R.id.edt_email);
        addr=findViewById(R.id.edt_addr);
        mob=findViewById(R.id.edt_mob);

        logi=findViewById(R.id.btn_log);
        reg=findViewById(R.id.btn_reg);
        clr=findViewById(R.id.btn_clr);



        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBUtil mDBU= DBUtil.getIntance(getApplicationContext());
                long insetData=mDBU.addData(uname.getText().toString(),pass.getText().toString(),name.getText().toString(),mail.getText().toString(),addr.getText().toString(),mob.getText().toString());
                if (insetData>0){
                    Toast.makeText(getApplicationContext(),"User Registered",Toast.LENGTH_LONG).show();
                    Intent i=new Intent(RegisterActivity.this,LoginActivity.class);
                    startActivity(i);
                }else {
                    Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG).show();
                }


            }
        });

        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uname.setText("");
                pass.setText("");
                name.setText("");
                mail.setText("");
                addr.setText("");
                mob.setText("");
            }
        });

        logi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
