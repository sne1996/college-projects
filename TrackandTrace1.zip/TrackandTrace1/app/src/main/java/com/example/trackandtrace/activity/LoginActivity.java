package com.example.trackandtrace.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.trackandtrace.R;
import com.example.trackandtrace.utils.DBUtil;
import com.example.trackandtrace.utils.PrefUtils;

public class LoginActivity extends AppCompatActivity {

    EditText uname,pass;
    Button logi,regl;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        uname=findViewById(R.id.edt_l_uname);
        pass=findViewById(R.id.etd_l_pass);
        logi=findViewById(R.id.btn_l_login);
        regl=findViewById(R.id.btn_l_reg);


        logi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBUtil mDBU= DBUtil.getIntance(getApplicationContext());
                Boolean check=mDBU.verify(uname.getText().toString(),pass.getText().toString());
                if(check==true){
                    Toast.makeText(getApplicationContext(),"Login",Toast.LENGTH_LONG).show();
                    PrefUtils.saveUserId(getApplicationContext(),uname.getText().toString());
                    Intent i =new Intent(LoginActivity.this,HomeActivity.class);
                    startActivity(i);
                    finish();

                }else {
                    Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG).show();
                }

            }
        });

        regl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(i);
            }
        });


    }
}
