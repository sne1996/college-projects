package com.example.trackandtrace.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import com.example.trackandtrace.R;
import com.example.trackandtrace.utils.DBUtil;


public class MainActivity extends AppCompatActivity {

    TextView txtV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtV=findViewById(R.id.txt);


/*        DBUtil mDBU = DBUtil.getIntance(getApplicationContext());
        Cursor data = mDBU.getData();
        while (data.moveToNext()) {
            *//*mArray_prod_list.add(new Product(data.getString(0), data.getString(1), data.getString(2),
                    data.getString(3), data.getInt(4)));*//*

            txtV.setText("User Name  --- :"+data.getString(0)+"  Passsword  :  "+data.getString(1)+"   Name  :  "+data.getString(2)+"  Email  :  "+data.getString(3));
        }*/

    }
}