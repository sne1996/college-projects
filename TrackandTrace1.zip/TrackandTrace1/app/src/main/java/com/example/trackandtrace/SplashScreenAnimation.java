package com.example.trackandtrace;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;

import com.example.trackandtrace.activity.HomeActivity;
import com.example.trackandtrace.activity.LoginActivity;
import com.example.trackandtrace.activity.MainActivity;
import com.example.trackandtrace.utils.PrefUtils;

public class SplashScreenAnimation extends AppCompatActivity {
    private Handler eHandler;
    private Runnable mRunnable;
    String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen_animation);

         id= PrefUtils.getUserId(getApplicationContext());

        mRunnable = new Runnable() {
            @Override
            public void run() {


                if(id.isEmpty()){
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
                }
                else {
                    startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                    finish();
                }
            }
        };

        eHandler = new Handler();

        eHandler.postDelayed(mRunnable, 2000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(eHandler != null && mRunnable != null)
            eHandler.removeCallbacks(mRunnable);
    }
}