package com.example.trackandtrace.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefUtils {


    /**
     * Storing API Key in shared preferences to
     * add it in header part of every retrofit request
     */

    private static final String PREF_NAME = "farmer";
    private static final String LOGGED_IN = "logged_in";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";


    public static boolean isLoggedIn(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
        return sharedPreferences.getBoolean(LOGGED_IN, true);
    }

    public PrefUtils() {
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }



    public static void saveUserId(Context context, String id) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString("user_id", id);
        editor.commit();
    }

    public static String getUserId(Context context) {
        return getSharedPreferences(context).getString("user_id", "");
    }

}
