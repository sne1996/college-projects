package com.example.trackandtrace.utils;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static android.accounts.AccountManager.KEY_PASSWORD;

public class DBUtil{

    private SQLiteDatabase mDb;
    private static final String DB_NAME="farmer_db";
    private static DBUtil dbUtil;

    private DBUtil(Context context){
        mDb=new PersonOpenHelper(context,DB_NAME,null,1).getWritableDatabase();
    }
    public static DBUtil getIntance(Context context){
        if (dbUtil==null){
            dbUtil=new DBUtil(context);
        }
        return dbUtil;
    }


    public Boolean verify(String uname,String pass){
        Cursor cursor=mDb.rawQuery("select * from tt where uname=? and pass=?",new String[]{uname,pass});
        if (cursor.getCount()>0)return true;
        else return false;
    }







    public long addData(String uname,String pass,String name,String email,String addr,String mob){

        ContentValues contentValues=new ContentValues();
        contentValues.put("uname", uname);
        contentValues.put("pass", pass);
        contentValues.put("name", name);
        contentValues.put("email", email);
        contentValues.put("addr", addr);
        contentValues.put("mob", mob);

        long result=mDb.insert("tt",null,contentValues);
        return result;
    }



  /*  public long updateData(Product product){
        ContentValues upValues =new ContentValues();
        upValues.put("price",product.getmProductPrice());
        upValues.put("stock",product.getmProductStock());
        upValues.put("decription", product.getmProductDiscribtion());
        upValues.put("image", product.getmImageId());
        String upWhere="name=?";
        String[] whereArgs={product.getmProductName()};

        return (long) mDb.update("product",upValues,upWhere,whereArgs);
    }

    public long deleteData(Product product){
        String upWhere="name=?";
        String[] whereArgs={product.getmProductName()};

        return (long) mDb.delete("product",upWhere,whereArgs);
    }*/
    


    public Cursor getData(){
        Cursor dat=mDb.query("tt",null,null,null,null,null,null);
        return dat;
    }
}

class PersonOpenHelper extends SQLiteOpenHelper {

    public PersonOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table tt ("+"uname text primary key,"+"pass text,"+"name text,"+"email text,"+"addr text,"+"mob text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
